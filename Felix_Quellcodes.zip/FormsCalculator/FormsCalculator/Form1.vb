﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Select()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Eingabe1 = TextBox1.Text
        Dim Eingabe2 = TextBox2.Text
        Dim Eingabe1dec As Decimal = Decimal.Parse(Eingabe1)
        Dim Eingabe2dec As Decimal = Decimal.Parse(Eingabe2)
        TextBox3.Text = ($"{Eingabe1dec + Eingabe2dec}")
        MessageBox.Show($"{Eingabe1dec + Eingabe2dec}")
    End Sub



    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Application.Exit()
    End Sub

End Class
