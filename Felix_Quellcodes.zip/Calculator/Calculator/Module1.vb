﻿Module Module1

    Sub Main()
        Console.WriteLine("Bitte geben Sie eine Zahl ein:")
        Dim Eingabe1 As String = Console.ReadLine()

        Console.WriteLine("Bitte geben Sie noch eine Zahl ein:")
        Dim Eingabe2 As String = Console.ReadLine()

        Dim Eingabe1int As Decimal = Decimal.Parse(Eingabe1)
        Dim Eingabe2int As Decimal = Decimal.Parse(Eingabe2)
        Dim Summe As Decimal = Eingabe1int + Eingabe2int
        Console.WriteLine($"Die Summe ist: {Summe}")
        Console.ReadKey()


    End Sub

End Module
