﻿Imports System.ComponentModel
Imports System.IO
Imports System.Xml.Serialization
Imports MeineKlassen

Public Class Form1

    Dim liste As New BindingList(Of Fahrzeug)

    Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        DataGridView1.DataSource = liste
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim neuesF As New Fahrzeug()
        neuesF.Hersteller = "Neu"
        neuesF.Leistung = 900
        liste.Add(neuesF)
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim neuerPKW As New PKW()
        neuerPKW.Hersteller = "PKW NEU"
        neuerPKW.Sitze = 789
        neuerPKW.Antriebsart = Antriebsart.EMotor
        liste.Add(neuerPKW)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim neuerLKW As New LKW()
        neuerLKW.Hersteller = "LKW NEU"
        neuerLKW.Schlafpl = False
        neuerLKW.Leistung = 400
        neuerLKW.Antriebsart = Antriebsart.Motor
        liste.Add(neuerLKW)
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim neuesSchiff As New Schiffe()
        neuesSchiff.Hersteller = "neues Schiff"
        neuesSchiff.Anker = 14
        neuesSchiff.Bullaugen = 8
        neuesSchiff.Laenge = 780
        neuesSchiff.AnzahlContainer = 1250
        liste.Add(neuesSchiff)
        neuesSchiff.Antriebsart = Antriebsart.Dampf

    End Sub

    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick

        Dim item As Object = DataGridView1.CurrentRow.DataBoundItem

        'todo hupen
        Dim einFzg As Fahrzeug = TryCast(item, Fahrzeug)
        If Not einFzg Is Nothing Then
            einFzg.Hupen()
        End If


        Dim istContainer As MeineKlassen.IContainer = TryCast(item, MeineKlassen.IContainer)
        If Not istContainer Is Nothing Then
            MessageBox.Show($"Kann Container: {istContainer.GetTypen()} Anzahl: {istContainer.AnzahlContainer}")

        End If






        If TypeOf item Is Schiffe Then                              'Typ Prüfung
            Dim einSchiff As Schiffe = CType(item, Schiffe)         'Typ Umwandlung (casting)
            MessageBox.Show($"Es ist ein Schiff mit {einSchiff.Anker} Ankern, {einSchiff.Bullaugen} Bullaugen, {einSchiff.Laenge} m")
        End If

        Dim einAuto As PKW = TryCast(item, PKW)
        If Not einAuto Is Nothing Then                   'Boxing
            MessageBox.Show($"Das ist ein Auto mit {einAuto.Sitze} Sitzen")
        End If

    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click

        Dim einSchiff As Schiffe = New Schiffe()

        'array == alt!!!                Pro: typisiert, Schnell  Contra: Statisch
        Dim Schiff(3) As Schiffe
        Schiff(1) = New Schiffe()
        Schiff(2) = New Schiffe()
        Schiff(3) = New Schiffe()

        Dim text As String = ""
        For index = 1 To Schiff.Length - 1
            text += Schiff(index).Hersteller
        Next

        'generic (generische) list              Pro: typisiert, dynamisch
        Dim liste As List(Of String) = New List(Of String)()
        liste.Add("Hallo") '0
        liste.Add("Das ist doof")   '1
        liste.Add("Und noch mehr Text") '2 -> 3
        liste.Insert(2, "Mehr Text!")
        liste.RemoveAt(1)

        ListBox1.Items.Clear()
        For Each item In liste
            ListBox1.Items.Add(item)

        Next


    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim dlg = New SaveFileDialog()
        dlg.Title = "Fahrzeugzieldatei auswählen"
        dlg.Filter = "Fahrzeugdateien|*.xml|Alle Dateien|*.*"


        If dlg.ShowDialog() = DialogResult.OK Then    'Windows standard Dialog "Speichen unter.." erscheint

            Dim sw = New StreamWriter(dlg.FileName)   'Imports System.IO

            Dim serial = New XmlSerializer(GetType(BindingList(Of Fahrzeug))) ' Imports System.Xml.Serialization

            serial.Serialize(sw, DataGridView1.DataSource)
            sw.Close()



        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim dlg = New OpenFileDialog()
        dlg.Title = "Fahrzeugzieldatei auswählen"
        dlg.Filter = "Fahrzeugdateien|*.xml|Alle Dateien|*.*"
        If dlg.ShowDialog() = DialogResult.OK Then    'Windows standard Dialog "Speichen unter.." erscheint

            Dim sr = New StreamReader(dlg.FileName)   'Imports System.IO
            Dim serial = New XmlSerializer(GetType(BindingList(Of Fahrzeug))) ' Imports System.Xml.Serialization

            DataGridView1.DataSource = serial.Deserialize(sr)

            sr.Close()
        End If
    End Sub
End Class
