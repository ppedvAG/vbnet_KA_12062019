﻿Public Interface IContainer

    Property AnzahlContainer As Integer

    Function GetTypen() As String


End Interface
