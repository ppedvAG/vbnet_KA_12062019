﻿Imports MeineKlassen

Public Class LKW
    Inherits Fahrzeug
    Implements IContainer

    Public Property Beladung As Integer
    Public Property Schlafpl As Boolean
    Public Property Laenge As Integer

    Public Property AnzahlContainer As Integer Implements IContainer.AnzahlContainer


    Public Function GetTypen() As String Implements IContainer.GetTypen
        Return "20Fuss"
    End Function
End Class
