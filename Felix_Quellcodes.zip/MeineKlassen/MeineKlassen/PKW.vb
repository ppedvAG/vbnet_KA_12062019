﻿
Public Class PKW
    Inherits Fahrzeug
    Public Property AnzahlRaeder As Integer
    Public Property Anhaengerkupplung As Boolean
    Public Property Sitze As Integer


End Class
