﻿Imports MeineKlassen

Public Class Schiffe
    Inherits Fahrzeug
    Implements IContainer

    Public Property Anker As Integer
    Public Property Bullaugen As Integer
    Public Property Laenge As Integer

    Public Property AnzahlContainer As Integer Implements IContainer.AnzahlContainer


    Public Overrides Sub Hupen()
        Console.Beep(250, 1200)
    End Sub

    Public Function GetTypen() As String Implements IContainer.GetTypen
        Return "20Fuss, 40Fuss"
    End Function
End Class
