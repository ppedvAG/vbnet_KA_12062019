﻿Public Class Fahrzeug

    Public Property Farbe As String
    Public Property Hersteller As String
    Public Property Modell As String
    Public Property Türen As Integer
    Public Property Leistung As Integer

    Public Overridable Sub Hupen()
        Console.Beep(Leistung, 500)
    End Sub


    Sub New() 'Konstruktor (jedes Mal wird beim Neuanlegen die Farbe auf Weiss gesetzt --> quasi DEFAULT-Werte setzen)
        Farbe = "weiss"
        Leistung = 100
    End Sub

    Public Property Antriebsart As Antriebsart = Antriebsart.Sonne 'Neue Spalte Anlegen und Default "Sonne" als Antriebsart (Hätte ich auch mit in den Konstruktor machen können)

End Class

Public Enum Antriebsart 'Enums sind einfache statische Listen mit festen Werten, eine Auflistung von möglichen Werten (auch eher Wertdatentyp)
    Motor
    EMotor
    Muskel
    Dampf
    Wind
    Sonne
End Enum

Public Structure Blö            'Structs sind Wertdatentypen(sowas wie nen Integer) keine Referencedatentypen liegen also auf dem Stack--> sind schnell, aber nur kurz benutzen sonst Stack Overload
    Property Zahl As Integer
End Structure