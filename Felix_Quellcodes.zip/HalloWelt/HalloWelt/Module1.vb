﻿Module Module1

    Sub Main()
        Dim text = "Hallo Welt"

        Console.WriteLine(text.ToUpper())
        Console.WriteLine(text.ToLower())
        Console.WriteLine(text)



        Console.ReadKey()
    End Sub

End Module
