﻿




Imports MeineKlassen
Module Module1

    Sub Main()
        Console.WriteLine("***MeineKlassenConsole***")
        Console.WriteLine("***Es geht Los!!!***")
        Console.WriteLine("...beliebige Taste drücken")
        Console.ReadKey()




        Dim fz1 As Fahrzeug = New Fahrzeug()
        fz1.Farbe = "Grau"
        fz1.Hersteller = "Benzedes"
        fz1.Modell = "V1"
        fz1.Türen = 8
        fz1.Leistung = 500
        fz1.Hupen()

        Dim fz2 As Fahrzeug = New Fahrzeug()
        fz2.Farbe = "Grün"
        fz2.Hersteller = "Wurstwagen"
        fz2.Modell = "A9"
        fz2.Türen = 2
        fz2.Leistung = 800
        fz2.Hupen()

        Console.WriteLine("ENDE")
        Console.ReadKey()
    End Sub

End Module
