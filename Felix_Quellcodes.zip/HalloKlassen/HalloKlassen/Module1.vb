﻿Module Module1

    Sub Main()
        Console.OutputEncoding = Text.Encoding.UTF8 'damit kann die Konsole das € Zeichen darstellen
        Console.WriteLine("**Hallo Klassen**")


        Dim Pizza As Essen            'Deklaration
        Pizza = New Essen()           'Instanzierung
        Pizza.Name = "Pizza"
        Pizza.IstVegetarisch = False
        Pizza.KCal = 1020
        Pizza.Preis = 8.5

        Dim Suppe As Essen = New Essen()            'Deklaration           'Instanzierung
        Suppe.Name = "Suppe"
        Suppe.IstVegetarisch = True
        Suppe.KCal = 300
        Suppe.Preis = 4.2

        ZeigeEssen(Pizza)
        ZeigeEssen(Suppe)

        Console.ReadKey()
        Console.WriteLine("Ende")
    End Sub

    Sub ZeigeEssen(einEssen As Essen)
        Console.WriteLine($"{einEssen.Name}: {einEssen.Preis:c} [{einEssen.KCal} KCal] {IIf(einEssen.IstVegetarisch, "veggetarisch", "")}")

    End Sub

End Module

Class Essen
    Public Name As String
    Public IstVegetarisch As Boolean
    Public KCal As Integer
    Public Preis As Decimal
End Class
