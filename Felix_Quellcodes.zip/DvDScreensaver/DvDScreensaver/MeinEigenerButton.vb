﻿Public Class MeinEigenerButton
    Inherits Button


    Public Overrides Property BackColor As Color
        Get
            Return MyBase.BackColor
        End Get
        Set(value As Color)


            MyBase.BackColor = value
        End Set
    End Property


    Protected Overrides Sub OnPaint(pevent As PaintEventArgs)
        'MyBase.OnPaint(pevent)

        pevent.Graphics.FillRectangle(Brushes.Black, Me.ClientRectangle)
        pevent.Graphics.FillEllipse(Brushes.Cornsilk, Me.ClientRectangle)

        Dim sf = New StringFormat()
        sf.LineAlignment = StringAlignment.Center
        sf.Alignment = StringAlignment.Center

        pevent.Graphics.DrawString(Me.Text, SystemFonts.CaptionFont, Brushes.DarkSlateGray, Me.ClientRectangle, sf)


    End Sub



End Class
